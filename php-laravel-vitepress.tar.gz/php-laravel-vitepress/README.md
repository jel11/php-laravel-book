# 📚 PHP & Laravel: От нуля до мессенджера

<div align="center">

![PHP](https://img.shields.io/badge/PHP-8.1+-777BB4?style=for-the-badge&logo=php&logoColor=white)
![Laravel](https://img.shields.io/badge/Laravel-11-FF2D20?style=for-the-badge&logo=laravel&logoColor=white)
![VitePress](https://img.shields.io/badge/VitePress-1.0-646CFF?style=for-the-badge&logo=vite&logoColor=white)

**Полное руководство по PHP и Laravel с практическими примерами**

[📖 Читать онлайн](https://your-site.com) • [🚀 Начать обучение](#быстрый-старт) • [💬 Обсудить](https://github.com/your-username/php-laravel-book/discussions)

</div>

---

## ✨ Особенности

- 📚 **82 главы** — от основ PHP до создания мессенджера
- 💻 **Практические примеры** — код, который можно сразу использовать
- 🎯 **От простого к сложному** — последовательное изложение
- 🔍 **Быстрый поиск** — найди нужную тему за секунды
- 📱 **Адаптивный дизайн** — читай с любого устройства
- 🌙 **Тёмная тема** — для комфортного чтения

## 📖 Содержание

### Основы
- **Часть 0**: Фундамент (HTTP, окружение, терминал)
- **Часть 1**: Основы PHP (синтаксис, функции, массивы)
- **Часть 2**: PHP и веб (формы, сессии, HTTP)

### Продвинутые темы
- **Часть 3**: Базы данных (SQL, MySQL, PDO)
- **Часть 4**: ООП в PHP
- **Часть 5**: Архитектура приложений (MVC, DI)
- **Часть 6**: Безопасность

### Laravel
- **Часть 7**: Composer и экосистема
- **Часть 8-10**: Laravel (от основ до продвинутого)
- **Часть 11**: Тестирование

### Современный стек
- **Часть 12**: Frontend интеграция (Vue.js)
- **Часть 13**: Real-time (WebSockets, чат)
- **Часть 14**: DevOps (Git, Docker, CI/CD)

## 🚀 Быстрый старт

### Установка

```bash
# Клонируй репозиторий
git clone https://github.com/your-username/php-laravel-book.git
cd php-laravel-book

# Установи зависимости
npm install

# Запусти локальный сервер
npm run docs:dev
```

Открой http://localhost:5173 в браузере.

### Собрать для продакшена

```bash
npm run docs:build
```

Файлы будут в папке `docs/.vitepress/dist/`.

## 📝 Работа с главами

### Готовые главы в markdown

Если у тебя уже есть готовые `.md` файлы:

1. Положи их в `docs/chapters/part-X/`
2. Они автоматически появятся в навигации

### Конвертация ответов Claude

Если Claude выдал главу в виде текста (не markdown):

```bash
# 1. Скопируй ответ Claude в файл chapter-3-2.txt

# 2. Конвертируй в markdown
python convert_chapter.py chapter-3-2.txt 3 2

# 3. Файл создастся в docs/chapters/part-3/chapter-3-2.md
```

### Массовая конвертация

Если есть папка с текстовыми файлами:

```bash
# Структура:
# claude-chapters/
#   chapter-1-1.txt
#   chapter-1-2.txt
#   chapter-2-1.txt
#   ...

python convert_chapter.py batch ./claude-chapters/
```

### Проверить прогресс

```bash
python convert_chapter.py progress
```

Покажет сколько глав заполнено.

## 🛠️ Структура проекта

```
php-laravel-book/
├── docs/
│   ├── .vitepress/
│   │   └── config.mts          # Конфигурация VitePress
│   ├── chapters/               # Все главы
│   │   ├── part-0/            # Фундамент
│   │   ├── part-1/            # Основы PHP
│   │   └── ...
│   ├── public/                # Статические файлы (картинки, логотип)
│   ├── index.md               # Главная страница
│   ├── intro.md               # О проекте
│   └── how-to-use.md          # Как пользоваться
├── convert_chapter.py         # Скрипт конвертации
├── package.json
└── README.md
```

## 🎨 Кастомизация

### Изменить тему

Отредактируй `docs/.vitepress/config.mts`:

```js
themeConfig: {
  // Цвета, логотип, навигация и т.д.
}
```

### Добавить новую главу

1. Создай файл `docs/chapters/part-X/chapter-X-Y.md`
2. Добавь в `sidebar` в `config.mts`:

```js
{
  text: 'X.Y Название главы',
  link: '/chapters/part-X/chapter-X-Y'
}
```

## 📊 Прогресс

- ✅ Часть 0: Фундамент (1/3)
- ⏳ Часть 1: Основы PHP (0/6)
- ⏳ Часть 2: PHP и веб (0/4)
- ⏳ ...

**Всего заполнено**: 1 / 82 глав (1.2%)

## 🤝 Вклад в проект

Хочешь помочь?

1. **Fork** репозиторий
2. Создай ветку: `git checkout -b feature/new-chapter`
3. Добавь контент
4. Commit: `git commit -m 'Add chapter X.Y'`
5. Push: `git push origin feature/new-chapter`
6. Создай **Pull Request**

### Что можно улучшить

- [ ] Заполнить пустые главы
- [ ] Добавить диаграммы и иллюстрации
- [ ] Создать интерактивные примеры
- [ ] Перевести на английский
- [ ] Добавить видео-материалы

## 📄 Лицензия

MIT License — свободно используй и модифицируй.

## 👨‍💻 Автор

**Jell**

- GitHub: [@your-username](https://github.com/your-username)
- Telegram: @your-telegram

## 🌟 Поддержка

Если учебник помог тебе — поставь ⭐ на GitHub!

---

<div align="center">

**Готов начать обучение?**

[📖 Открыть учебник](https://your-site.com) • [🚀 Глава 0.1](docs/chapters/part-0/chapter-0-1.md)

</div>
