---
layout: home

hero:
  name: "PHP & Laravel"
  text: "От нуля до мессенджера"
  tagline: Полное руководство по PHP и Laravel с практическими примерами
  image:
    src: /logo.svg
    alt: PHP & Laravel
  actions:
    - theme: brand
      text: Начать обучение →
      link: /chapters/part-0/chapter-0-1
    - theme: alt
      text: О проекте
      link: /intro

features:
  - icon: 📚
    title: 82 главы
    details: От основ PHP до создания real-time мессенджера на Laravel
  - icon: 💻
    title: Практические примеры
    details: Каждая глава содержит примеры кода и упражнения
  - icon: 🎯
    title: От простого к сложному
    details: Последовательное изложение без резких скачков в сложности
  - icon: 🚀
    title: Итоговый проект
    details: К концу курса ты создашь полноценный мессенджер
  - icon: 🔍
    title: Быстрый поиск
    details: Найди нужную тему за секунды
  - icon: 📱
    title: Адаптивный дизайн
    details: Читай с телефона, планшета или компьютера
---

## 🎓 Что ты изучишь?

<div class="features-grid">

### Основы PHP
Синтаксис, переменные, функции, массивы, работа с файлами

### Работа с веб
Формы, сессии, куки, HTTP-заголовки, обработка данных

### Базы данных
SQL, MySQL, PDO, проектирование схем, оптимизация запросов

### ООП
Классы, наследование, интерфейсы, SOLID-принципы

### Laravel Framework
От основ до продвинутых техник: Eloquent, Blade, API, очереди

### Real-time функционал
WebSockets, Broadcasting, создание чата

### Тестирование
Unit-тесты, Feature-тесты, TDD

### DevOps
Git, Docker, деплой, CI/CD

</div>

## 🚀 Быстрый старт

1. **Выбери главу** из меню слева
2. **Читай теорию** и изучай примеры
3. **Выполняй упражнения** для закрепления
4. **Отмечай прогресс** по мере изучения

## 💡 Для кого этот учебник?

- ✅ Начинающие разработчики
- ✅ Знающие основы программирования и желающие освоить PHP
- ✅ PHP-разработчики, переходящие на Laravel
- ✅ Те, кто хочет создать реальный проект

## 📖 Структура учебника

- **Часть 0-2**: Основы PHP и веб-разработки
- **Часть 3**: Работа с базами данных
- **Часть 4-5**: ООП и архитектура приложений
- **Часть 6**: Безопасность веб-приложений
- **Часть 7**: Composer и экосистема PHP
- **Часть 8-10**: Laravel от простого к сложному
- **Часть 11**: Тестирование
- **Часть 12**: Frontend интеграция
- **Часть 13**: Real-time функционал
- **Часть 14**: DevOps и деплой

---

<div style="text-align: center; margin-top: 3rem;">
  <a href="/chapters/part-0/chapter-0-1" class="vp-button vp-button-brand">Начать обучение →</a>
</div>

<style>
.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  margin: 2rem 0;
}

.features-grid h3 {
  font-size: 1.1rem;
  margin-top: 0.5rem;
  color: var(--vp-c-brand);
}

.features-grid p {
  font-size: 0.9rem;
  color: var(--vp-c-text-2);
}
</style>
