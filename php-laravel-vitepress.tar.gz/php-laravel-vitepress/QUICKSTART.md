# 🚀 Быстрый старт

## Шаг 1: Установка

```bash
# Клонируй репозиторий (или распакуй архив)
cd php-laravel-vitepress

# Установи Node.js если ещё нет
# Скачай с https://nodejs.org (версия 18+)

# Установи зависимости
npm install
```

## Шаг 2: Запуск

```bash
# Запусти локальный сервер
npm run docs:dev
```

Открой в браузере: **http://localhost:5173**

## Шаг 3: Добавление глав

### Вариант А: У тебя уже есть markdown файлы

Просто скопируй их в `docs/chapters/part-X/`:

```bash
cp твоя-глава.md docs/chapters/part-1/chapter-1-1.md
```

### Вариант Б: Claude выдал главу текстом

1. Скопируй ответ Claude в файл `chapter-3-2.txt`

2. Конвертируй:
```bash
python convert_chapter.py chapter-3-2.txt 3 2
```

3. Готово! Файл создан в `docs/chapters/part-3/chapter-3-2.md`

### Вариант В: Массовая конвертация

Если у тебя много текстовых файлов с главами:

```bash
# Положи их в папку (имена: chapter-1-1.txt, chapter-1-2.txt и т.д.)
mkdir claude-chapters
# Скопируй туда все .txt файлы

# Конвертируй все сразу
python convert_chapter.py batch ./claude-chapters/
```

## Шаг 4: Проверка прогресса

```bash
python convert_chapter.py progress
```

Увидишь:
```
📊 Прогресс заполнения:

part-0: ███░░░░░░░ 1/3 (33%)
part-1: ░░░░░░░░░░ 0/6 (0%)
...

🎯 Общий прогресс: 1/66 глав (1.5%)
```

## Шаг 5: Сборка для публикации

```bash
# Собрать статические файлы
npm run docs:build

# Файлы в docs/.vitepress/dist/
# Можешь залить на GitHub Pages, Netlify, Vercel
```

## 🎯 Типичный workflow

### Ежедневная работа:

1. Открой Claude проект с промптами
2. Скопируй промпт главы
3. Получи ответ от Claude
4. Скопируй в файл `chapter-X-Y.txt`
5. Конвертируй: `python convert_chapter.py chapter-X-Y.txt X Y`
6. Проверь результат в браузере

### Пример конкретной сессии:

```bash
# 1. Запускаешь сервер (раз в день)
npm run docs:dev

# 2. Генерируешь главы в Claude

# 3. Конвертируешь полученные главы
python convert_chapter.py chapter-1-1.txt 1 1
python convert_chapter.py chapter-1-2.txt 1 2
python convert_chapter.py chapter-1-3.txt 1 3

# 4. Проверяешь прогресс
python convert_chapter.py progress

# 5. В конце дня коммитишь
git add .
git commit -m "Add chapters 1.1-1.3"
git push
```

## 📝 Пример: Добавляем главу 3.2

У тебя есть текстовый ответ Claude про "MySQL и проектирование БД".

```bash
# 1. Сохрани ответ в файл
nano chapter-3-2.txt
# (вставь текст, Ctrl+X, Y, Enter)

# 2. Конвертируй
python convert_chapter.py chapter-3-2.txt 3 2

# Вывод:
# ✅ Создан файл: docs/chapters/part-3/chapter-3-2.md
#    Заголовок: Глава 3.2: MySQL и проектирование БД

# 3. Проверь в браузере
# Глава автоматически появится в навигации!
```

## 🐛 Возможные проблемы

### "Command not found: npm"

Нужно установить Node.js:
- Скачай с https://nodejs.org
- Установи версию 18 или новее

### "Python not found"

Установи Python 3:
- Windows: https://www.python.org/downloads/
- Mac: `brew install python3`
- Linux: `sudo apt install python3`

### "Модуль не найден"

Переустанови зависимости:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Главы не конвертируются

Проверь формат имени файла:
- ✅ Правильно: `chapter-3-2.txt` или `3-2.txt`
- ❌ Неправильно: `chapter3-2.txt` или `глава-3-2.txt`

## 🎉 Готово!

Теперь у тебя есть:
- ✅ Работающий локальный сайт
- ✅ Инструмент для конвертации глав
- ✅ Красивая навигация
- ✅ Поиск по содержимому

**Начинай заполнять главы и создавать учебник мечты!** 🚀

---

**Вопросы?** Создай issue на GitHub или посмотри [README.md](README.md)
